import logging as log
log = log.getLogger(__name__)
def two():
	log.info('message_2')