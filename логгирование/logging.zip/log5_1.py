import logging as log
log = log.getLogger(__name__)
def one():
	log.info('message_1')
