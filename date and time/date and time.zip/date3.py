from datetime import *
d = date(2018, 3, 18)
print(d.strftime('%A, %d %B/%Y'))