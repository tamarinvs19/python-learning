from datetime import *
delta = date(2020, 3, 15) - date(2020, 1, 15)
print(delta)