from datetime import *

d = date(2020, 2, 29)
print(d.strftime('%d %B %Y'))